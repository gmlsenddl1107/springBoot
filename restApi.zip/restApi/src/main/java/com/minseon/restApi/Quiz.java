package com.minseon.restApi;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "paige_quiz")
@Getter
@Setter
@NoArgsConstructor
public class Quiz{
    @NotNull
    @Id
    @GeneratedValue
    private long id;

    //중복 금지
    @NotNull
    @Size(min=1)
    @Column(length = 50)
    private String question;

    @Column()
    private Integer quiz_category;

    @Column(length=20)
    private String duration;

    @Column(length=20)
    private String answer;

    @Column(length=20)
    private String option1;

    @Column(length=20)
    private String option2;

    @Column(length=20)
    private String option3;

    @Column()
    private Integer num_options;

    @Column(length = 20)
    private String comment;

    @Column(length = 20)
    private String qa_team_id;

    @Column()
    private Integer qa_player_id;


    public Quiz(@NotNull @Size(min = 1) String question, Integer quiz_category, String duration, String answer, String option1, String option2, String option3, Integer num_options, String comment, String qa_team_id, Integer qa_player_id) {
        this.question = question;
        this.quiz_category = quiz_category;
        this.duration = duration;
        this.answer = answer;
        this.option1 = option1;
        this.option2 = option2;
        this.option3 = option3;
        this.num_options = num_options;
        this.comment = comment;
        this.qa_team_id = qa_team_id;
        this.qa_player_id = qa_player_id;
    }
}
