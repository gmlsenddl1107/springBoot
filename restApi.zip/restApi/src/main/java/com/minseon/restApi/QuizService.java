package com.minseon.restApi;


import com.sun.media.sound.InvalidDataException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import javax.transaction.Transactional;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class QuizService {

    @Autowired
    private QuizRepository quizRepository;

    public List<Quiz> getQuizs() {

        return quizRepository.findAll();

    }



    @Transactional
    public void generateQuiz() {

        List<Quiz> quizs = new ArrayList<Quiz>();
        for(int i = 1;i<10;i++) {
            quizs.add(new Quiz("quiz".concat(Integer.toString(i)),36,"n","폭죽","물","페트병 음료수","풍선",4,"","",12));
        }

        quizRepository.saveAll(quizs);
    }



    @Transactional
    public int saveQuizs(List<Quiz> quizs){
        quizRepository.saveAll(quizs);
        return quizs.size();
    }

    public List<Quiz> uploadExcelQuiz(MultipartFile file,int isColumnName) throws InvalidFormatException, IOException {
        List<Quiz> quizs = new ArrayList<>();

        if(file.isEmpty()){
            throw new InvalidFormatException("file is empty.");

        }else if(!Objects.requireNonNull(file.getOriginalFilename()).endsWith("xlsx")){
            //Objects.requireNonNull의 경우 endsWith가 nullpointexception을 일으키는 걸 방지


            throw new InvalidFormatException("file is not 'xlsx' format. ");
        }


        try {
                Workbook wb= new XSSFWorkbook(file.getInputStream());
                Sheet sheet = wb.getSheetAt(0);
                int rowSize = sheet.getLastRowNum();


                if (rowSize < 2){
                    throw new InvalidDataException("the number of row in file must be larger than 1. (included column name row) ");
                }
                for(int rowNum = isColumnName;rowNum<rowSize;rowNum++) {
                    Row row= sheet.getRow(rowNum);
                    Quiz quiz =new Quiz();
                    quiz.setQuestion(getCellValue(row.getCell(0)));
                    quiz.setQuiz_category( (int) Double.parseDouble(getCellValue(row.getCell(1))));
                    quiz.setDuration(getCellValue(row.getCell(2)));
                    quiz.setAnswer(getCellValue(row.getCell(3)));
                    quiz.setOption1(getCellValue(row.getCell(4)));
                    quiz.setOption2(getCellValue(row.getCell(5)));
                    quiz.setOption3(getCellValue(row.getCell(6)));
                    quiz.setNum_options((int) Double.parseDouble(getCellValue(row.getCell(1))));
                    quiz.setComment(getCellValue(row.getCell(8)));
                    quiz.setQa_team_id(getCellValue(row.getCell(9)));
                    quiz.setQa_player_id((int) Double.parseDouble(getCellValue(row.getCell(1))));
                    quizs.add(quiz);

                }
        } catch (InvalidDataException ex){
                ex.printStackTrace();
        }
        return quizs;
    }


    private String getCellValue(Cell cell) {

        switch (cell.getCellTypeEnum()) {
            case BOOLEAN:
                boolean boolCell = cell.getBooleanCellValue();
                return Boolean.toString(boolCell);

            case NUMERIC:
                double NumericCell = cell.getNumericCellValue();
                return Double.toString(NumericCell);

            case STRING:
                String cellValue = cell.getStringCellValue();
                return cellValue;


                ////다른 케이스의 경우////////////
        }
        return null;
    }

    //read only와 같은 권한 제어어
    @Transactional()
    public Slice<Quiz> getQuizsPage(int page, int size){
        if(page <= 0){
            page = 1;
        }

        Pageable pageable= PageRequest.of(page,size);
        Slice<Quiz> quizs = quizRepository.findAllBy(pageable);
        return quizs;
    }


}
