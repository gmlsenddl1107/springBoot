package com.minseon.restApi;


import net.bytebuddy.implementation.bind.MethodDelegationBinder;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
public class QuizController {

    @Autowired
    private QuizService service;

    @GetMapping(path = "/quizs")
    public List<Quiz> getQuizs(){
        service.generateQuiz();
        return service.getQuizs();

    }

//    @GetMapping(path = "/quizs/{page}")
//    public List<Quiz> getQuizsPerPage(@PathVariable int page){
//        service.generateQuiz();
//        return String.format("%s",page);
//
//    }

    @PostMapping(path="/quizs")
    public int saveQuizs(@RequestBody MultipartFile file) throws IOException, InvalidFormatException {
        int savedNum = 0;

        List<Quiz> quizs = service.uploadExcelQuiz(file,1);
        savedNum =service.saveQuizs(quizs);
        return savedNum;
    }



}
